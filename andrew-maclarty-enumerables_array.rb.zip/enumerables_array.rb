require 'byebug'

class Array 
    def my_each(&block)
        length = self.length 
        length.times do |i|
            block.call(self[i])
        end
        self
    end

    def my_select(&block)
        selected_eles = []
        self.my_each do |ele|
            if block.call(ele)
                selected_eles << ele  
            end 
        end
        selected_eles
    end

    def my_any?(&block)
        self.my_each do |ele|
            if &block.call(ele) 
                return true 
            end 
        end
    end

    def my_all?(&block)
        self.my_each do |ele|
            if !block.call(ele) 
                return false 
            end
        end
        true
    end

    def my_reverse 
        reversed = [] 
        self.my_each do |ele|
            reversed.unshift(ele) 
        end 
        reversed 
    end

end